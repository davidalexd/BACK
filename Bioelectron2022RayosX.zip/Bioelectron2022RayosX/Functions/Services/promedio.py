def promedio(attributes):
    promedio = 0 
    promedio = sum(attributes)/len(attributes)
    resultado = promedio
    return resultado