def mediciones(opcion):
    if (opcion == 2):
        return 115

    if (opcion == 3):
        return 110

    if (opcion == 4):
        return 105

    if (opcion == 4.5):	
        return 103

    if (opcion == 5):
        return 100

    if (opcion == 6):
        return 95

    if (opcion == 7):
        return 90
        
    else:
        return None
