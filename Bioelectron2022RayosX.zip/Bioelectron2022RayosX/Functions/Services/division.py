def division(dividendo,divisor):
    cociente = 0
    cociente = dividendo/divisor
    resultado = {"valor":cociente}
    return resultado