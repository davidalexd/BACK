def menor_igual_que(element,element_comparacion):
    comparacion = False
    comparacion = element<=element_comparacion
    resultado = {"valor":comparacion}
    return resultado