def multiplicacion(factor_a,factor_b):
    producto = 0
    producto = factor_a * factor_b
    resultado = {"valor":producto}
    return resultado
