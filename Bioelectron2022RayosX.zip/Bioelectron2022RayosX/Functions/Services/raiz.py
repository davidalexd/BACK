def raiz(radicando,radical):
    raiz = 0
    raiz = pow(radicando,1/radical)
    resultado = raiz
    return resultado

