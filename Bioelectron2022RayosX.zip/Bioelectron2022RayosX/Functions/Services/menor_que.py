def menor_que(element,element_comparacaion):
    comparacion = False
    comparacion = element<element_comparacaion
    resultado = {"valor":comparacion}
    return resultado