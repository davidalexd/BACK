def interpolar_bidimencionalmente(element_1,element_2):
