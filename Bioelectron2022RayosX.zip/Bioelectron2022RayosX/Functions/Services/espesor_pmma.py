def espesor_pmma():
    return [2,3,4,4.5,5,6,7]