
def array_list(attributes):
    Uc = []
    for x in attributes:
        Uc.append(float(x["valor"]))
    return Uc